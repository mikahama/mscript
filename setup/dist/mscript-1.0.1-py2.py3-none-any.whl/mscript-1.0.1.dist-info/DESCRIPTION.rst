MScript

MScript is a tool for compiling MScript files into JavaScript. This python package installs a commandline tool called mscript but it's also possible to compile .mscript files by using this python library directly from your python code.

More information at http://mikakalevi.com/mscript

